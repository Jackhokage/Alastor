if (connection == 'open') {
console.log(chalk.yellowBright('\n╭━─━━─━━─━─≪  𐂂  ≫─━─━━─━━─━╮\n│\n│𝐂𝐎𝐍𝐄𝐂𝐓𝐀𝐃𝐎 𝐂𝐎𝐑𝐑𝐄𝐂𝐓𝐀𝐌𝐄𝐍𝐓𝐄 𝐀 𝐋𝐀 𝐓𝐑𝐀𝐍𝐒𝐌𝐈𝐒𝐈𝐎𝐍.\n│\n╰━─━━━─━━─━─≪ 𐂂 ≫─━─━━─━━━─━╯\n'))
conn.fakeReply('(+5493804165438)@s.whatsapp.net', '😄', '0@s.whatsapp.net', '𝐒𝐄 𝐈𝐍𝐈𝐂𝐈𝐎 𝐋𝐀 𝐓𝐑𝐀𝐍𝐒𝐌𝐈𝐒𝐈𝐎𝐍 𝐃𝐄 𝐀𝐋𝐀𝐒𝐓𝐎𝐑, 𝐀𝐒𝐓𝐑𝐀𝐋', '0@s.whatsapp.net')
   }