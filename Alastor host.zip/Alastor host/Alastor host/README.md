# `Jotchua-Bot` 


### `grupos del Bot`

<a href="https://chat.whatsapp.com/FRkr7jJHSJA5OjVtE64dDs" target="blank"><img src="https://img.shields.io/badge/grupo Bot-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" /></a>

<a href="https://chat.whatsapp.com/FRkr7jJHSJA5OjVtE64dDs" target="blank"><img src="https://img.shields.io/badge/grupo bot-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" /></a>


 ### `BOT OFICIAL`

<a href="https://api.whatsapp.com/send/?phone=5219991402134&text=/estado&type=phone_number&app_absent=0" target="blank"><img src="https://img.shields.io/badge/BOT_OFICIAL_1_(INACTIVO)-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />

### `▢ PLUGINS`
- TIENES IDEAS DE PLUGINS O QUIERES OBTENER MAS PLUGINS? DA CLICK EN [https://github.com/theh2so4/Mystic-Plugins](https://github.com/theh2so4/Mystic-Plugins)

### `AJUSTES`
- CLONAR EL REPOSITORIO [Aqui](https://github.com/AleXD0009/Jotchua/fork)
- CAMBIAR NÚMERO DEL PROPIETARIO(A) [Aqui](https://github.com/AleXD0009/Jotchua/blob/master/config.js)
  
### `▢ ACTIVAR EN KOYEB`

[![Deploy to Koyeb](https://www.koyeb.com/static/images/deploy/button.svg)](https://app.koyeb.com/deploy?type=git&repository=https://github.com/AleXD0009/Jotchua&branch=master&name=JotchuaBot)
  
### `▢ ACTIVAR EN REPLIT`

[![Run on Repl.it](https://repl.it/badge/github/AleXD0009/Jotchua)](https://repl.it/github/BrunoSobrino/TheMystic-Bot-MD) 
  
### `▢ ACTIVAR EN RENDER`

[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://dashboard.render.com/blueprint/new?repo=https%3A%2F%2Fgithub.com%2FAleXD0009%2FTJotchua) 

### `▢ ACTIVAR EN TERMUX` 
- ESCRIBE LOS SIGUIENTES COMANDOS UNO POR UNO:
```bash
cd && termux-setup-storage
```

```bash
apt-get update -y && apt-get upgrade -y
```

```bash
pkg install -y git nodejs ffmpeg imagemagick && pkg install yarn 
```

```bash
git clone https://github.com/AleXD0009/Jotchua.git && cd Jotchua
```

```bash
yarn install
```

```bash
npm install
```

```bash
npm update
```

```bash
npm start
```

### `▢ ACTIVAR EN CASO DE DETENERSE EN TERMUX`
```bash
ESCRIBE LOS SIGUIENTES COMANDOS UNO POR UNO:
> cd 
> cd Mystic-termux
> npm start
```

### `▢ OBTENER OTRO CODIGO QR EN TERMUX`
- DETEN EL BOT, HAZ CLICK EN EL SIMBOLO CTRL DE TERMUX MAS Z EN SU TECLADO MOVIL HASTA QUE SALGA ALGO EN VERDE SIMILAR A Mystic-termux $  
```bash
ESCRIBE LOS SIGUIENTES COMANDOS UNO POR UNO:
> cd 
> cd Mystic-termux
> rm -rf MysticSession
> npm start
```

### `▢ ACTIVAR EN ZIPPONODES`
<a href="https://www.zipponodes.com"><img src="https://cdn.zipponodes.com/zipponodes/logos/logo_zipponodes_transparent2.png" width="350" height="130" alt="PNG"/></a>
- Sitio web: [zipponodes.com](https://www.zipponodes.com)
- Dash: [dash.zipponodes.com](https://dash.zipponodes.com)
- Panel: [panel.zipponodes.com](https://panel.zipponodes.com)
- Documentación: [docs.zipponodes.com](https://docs.zipponodes.com)
- Grupo de WhatsApp: [whatsapp.zipponodes.com](https://whatsapp.zipponodes.com)


### `▢ ACTIVAR EN BOXMINEHOST`
<a href="https://boxmineworld.com"><img src="https://raw.githubusercontent.com/AleXD0009/Jotchua/master/src/Pre%20Bot%20Publi.png" width="450" height="240" alt="JPG"/></a>
- Pagina Oficial: [https://boxmineworld.com](https://boxmineworld.com)
- Dashboard: [https://dash.boxmineworld.com](https://dash.boxmineworld.com)
- Panel: [https://panel.boxmineworld.com](https://panel.boxmineworld.com)
- Tutorial: [https://youtu.be/eC9TfKICpcY](https://youtu.be/eC9TfKICpcY)
- Dudas UNICAMENTE SOBRE EL HOST: [https://discord.gg/84qsr4v](https://discord.gg/84qsr4v) (Preguntar por Vicemi)

### `▢ NOTAS`
- ES POSIBLE QUE EL BOT TENGA ALGUNAS FALLAS, SE IRAN SOLUCIONANDO CONFORME SE VAYAN DETECTANDO
- SI VAS A EDITAR POR COMPLETO DEJA LOS CREDITOS DEL BOT 
- EL BOT ES COMPARTIBLE CON WHATSAPP NORMAL O BUSINESS
- ATENTO A LAS ACTUALIZACIONES QUE SE HAGAN EN ESTE REPOSITORIO
- PUEDES USAR #actualizacion PARA VER SI ALGUN COMANDO FUE ACTUALIZADO
- EL ADD Y EL KICK PUEDEN OCASIONAR QUE EL NUMERO SE VAYA A SOPORTE POR ELLO SE ACTIVA CON #enable restrict 
- THE SHADOW BROKERS - TEAM NO SE HACE RESPONSABLE DEL USO, NUMEROS, PRIVACIDAD Y CONTENIDO MANDADO, USADO O GESTIONADO POR USTEDES O EL BOT
 

## `▢ COLABORADORES DEL BOT` 
<a href="https://github.com/unptoadrih15"><img src="https://github.com/unptoadrih15.png" width="100" height="100" alt="unptoadrih15"/></a>
<a href="https://github.com/ALBERTO9883"><img src="https://github.com/ALBERTO9883.png" width="100" height="100" alt="ALBERTO9883"/></a>
<a href="https://github.com/ferhacks"><img src="https://github.com/ferhacks.png" width="100" height="100" alt="ferhacks"/></a>
<a href="https://github.com/G4tito"><img src="https://github.com/G4tito.png" width="100" height="100" alt="G4tito"/></a>
<a href="https://github.com/GataNina-Li"><img src="https://github.com/GataNina-Li.png" width="100" height="100" alt="GataNina-Li"/></a>
<a href="https://github.com/OsExar"><img src="https://github.com/OsExar.png" width="100" height="100" alt="OsExar"/></a>
<a href="https://github.com/CarlosTwT"><img src="https://github.com/CarlosTwT.png" width="100" height="100" alt="CarlosTwT"/></a>
<a href="https://github.com/anxo2077"><img src="https://github.com/anxo2077.png" width="100" height="100" alt="anxo2077"/></a>
<a href="https://github.com/GeneradorVIP"><img src="https://github.com/GeneradorVIP.png" width="100" height="100" alt="GeneradorVIP"/></a>
<a href="https://github.com/DIEGO-OFC"><img src="https://github.com/DIEGO-OFC.png" width="100" height="100" alt="DIEGO-OFC"/></a>
<a href="https://github.com/SinNombre999"><img src="https://github.com/SinNombre999.png" width="100" height="100" alt="SinNombre999"/></a>
<a href="https://github.com/ReyEndymion"><img src="https://github.com/ReyEndymion.png" width="100" height="100" alt="ReyEndymion"/></a>
<a href="https://github.com/theh2so4"><img src="https://github.com/theh2so4.png" width="100" height="100" alt="theh2so4"/></a>
<a href="https://github.com/skidy89"><img src="https://github.com/skidy89.png" width="100" height="100" alt="skidy89"/></a>
<a href="https://github.com/OFC-YOVANI"><img src="https://github.com/OFC-YOVANI.png" width="100" height="100" alt="OFC-YOVANI"/> </a>
<a href="https://github.com/elrebelde21"><img src="https://github.com/elrebelde21.png" width="100" height="100" alt="elrebelde21"/> </a>
<a href="https://github.com/Fabri115"><img src="https://github.com/Fabri115.png" width="100" height="100" alt="Fabri115"/> </a>

## `▢ AGRADECIMIENTOS & CREDITOS` 
<div><button id="boton" type="button">games-wabot-md - By BochilGaming </button></div>
<a href="https://github.com/BochilGaming/games-wabot-md/tree/multi-device"><img src="https://github.com/BochilGaming.png" width="150" height="150" alt="BochilGaming"/></a>
<div><button id="boton" type="button">Baileys - By WhiskeySockets & adiwajshing</button></div>
<a href="https://github.com/WhiskeySockets/Baileys"><img src="https://github.com/WhiskeySockets.png" width="150" height="150" alt="adiwajshing"/></a>
<a href="https://github.com/BrunoSobrino"><img src="https://github.com/BrunoSobrino.png" width="250" height="250" alt="BrunoSobrino"/></a>

## `▢ EDITOR & PROPIETARIO DEL BOT` 
<a href="https://github.com/AleXD0009"><img src="https://github.com/AleXD0009.png" width="250" height="250" alt="AleXD0009"/></a>
  
`Jotchua Bot by ALS`
